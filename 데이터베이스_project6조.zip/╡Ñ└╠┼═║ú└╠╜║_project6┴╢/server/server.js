const express = require('express')
const bodyParser = require('body-parser')
const sql = require('mssql')
const crypto = require('crypto')
const app = express()
const port = 3001

const dir = "/Users/leafn/Documents/temp/server"

const salt = "DBPROJECT@@"


const ok = {"result" : "ok"}
const fail = {"result" : "fail"}

const config = {
    user: 'sa',
    password: '12331233a',
    server: '192.168.208.128',
    database: 'DBProject10',
 
    options: {
        encrypt: false
    }
}

const pool = new sql.ConnectionPool(config).connect()

var session = require('express-session')

app.use(session({
    secret: '33D2EC797B093F74392C89F5A49D081AA34D0B275E8BB1532835CBC14136C53A',
    resave: false,
    saveUninitialized: true
}))

app.use(express.static(dir + '/build'))

app.use(bodyParser.urlencoded({ extended:false }))
app.use(bodyParser.json())

// main

app.get('/', (req, res) => {
    res.send('Hello World!')
})

app.get('/mypage', (req, res) => {
    //res.sendFile(dir + '/build/mypage.html')
    var sess = req.session
    if (sess.userId) {
        console.log(sess.userId)
        res.sendFile(dir + '/build/mypage.html')
    } else {
        res.redirect('/sign_in')
    }
})

app.get('/game', (req, res) => {
    //res.sendFile(dir + '/build/mypage.html')
    var sess = req.session
    if (sess.userId) {
        console.log(sess.userId)
        res.sendFile(dir + '/build/game.html')
    } else {
        res.redirect('/sign_in')
    }
})

app.get('/match', (req, res) => {
    //res.sendFile(dir + '/build/mypage.html')
    var sess = req.session
    if (sess.userId) {
        console.log(sess.userId)
        res.sendFile(dir + '/build/match.html')
    } else {
        res.redirect('/sign_in')
    }
})

app.get('/competition', (req, res) => {
    //res.sendFile(dir + '/build/mypage.html')
    var sess = req.session
    if (sess.userId) {
        console.log(sess.userId)
        res.sendFile(dir + '/build/competition.html')
    } else {
        res.redirect('/sign_in')
    }
})

app.get('/group', (req, res) => {
    var sess = req.session
    if (sess.userId) {
        console.log(sess.userId)
        res.sendFile(dir + '/build/group.html')
    } else {
        res.redirect('/sign_in')
    }
})

app.post("/logout", (req, res) => {
    var sess = req.session
    sess.destroy()

    res.json(ok)
})

app.post('/mypage_getUserData', (req, res) => {
    var sess = req.session
    if (sess.userId) {
        var query = `SELECT UPhone, Uname, Ulocation, Birth, Email FROM PLAYER WHERE User_Id = ${sess.userId}`
        console.log(query)
        new sql.ConnectionPool(config).connect().then((pool) => {
            return pool.query(query)
        }).then(result => {
            console.log(result)

            res.json({
                "result" : "ok",
                "name" : result.recordset[0].Uname,
                "birth" : result.recordset[0].Birth.toISOString().slice(0, 10),
                "location" : result.recordset[0].Ulocation,
                "phone" : result.recordset[0].UPhone,
                "email" : result.recordset[0].Email,
            })
        }).catch(err => {
            console.log(err)
            res.json(fail)
        })
    } else {
        res.json(fail)
    }
})

app.post('/mypage_getStatistic', (req, res) => {

})

app.post('/mypage_getLastMatch', (req, res) => {

})

app.post('/mypage_getLastGame', (req, res) => {

})

app.post('/mypage_getLastCpp', (req, res) => {

})

app.post('/mypage_getLastUser', (req, res) => {

})

app.get('/sign_in', (req, res) => {

    var sess = req.session
    if (!sess.userId) {
        res.sendFile(dir + '/build/signin.html')
    } else {
        res.redirect('/mypage')
    }
    //res.sendFile(dir + '/build/signin.html')
})

app.post('/sign_in', (req, res) => {
    var email = req.body.email
    var password = req.body.password

    if (!email || !password) {
        res.json(fail)
        return
    }

    password = crypto.createHash('sha256').update(salt + password).digest('hex');

    var query = `SELECT User_Id, PW FROM PLAYER WHERE Email = '${email}'`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        if (result.recordsets.length != 0) {
            dbPassword = result.recordset[0].PW
            dbUserId = result.recordset[0].User_Id

            console.log(result)

            console.log(dbPassword)
            console.log(password)

            if (dbPassword == password) {
                var sess = req.session
                sess.userId = dbUserId

                res.json(ok)
            } else {
                res.json(fail)
            }
        } else {
            res.json(fail)
        }
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

})

app.get('/sign_up', (req, res) => {

    var sess = req.session
    if (!sess.userId) {
        res.sendFile(dir + '/build/signup.html')
    } else {
        res.redirect('/mypage')
    }
})

app.post('/sign_up', (req, res) => {

    var name = req.body.name
    var email = req.body.email
    var password = req.body.password 
    var phone = req.body.phone
    var birth = req.body.birth
    var location = req.body.location

    if (!name || !email || !password || !phone || !birth || !location) {
        res.json(fail)
        return
    }

    password = crypto.createHash('sha256').update(salt + password).digest('hex');

    var query = `INSERT INTO PLAYER(PW, UPhone, Uname, Ulocation, Birth, Email) VALUES('${password}', '${phone}','${name}', '${location}', '${birth}', '${email}')`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        var getUserId = `SELECT User_Id FROM PLAYER WHERE email = '${email}'`

        new sql.ConnectionPool(config).connect().then((pool) => {
            return pool.query(getUserId)
        }).then(getResult => {
            if (getResult.recordset[0].User_Id != null) {
                var sess = req.session
                sess.userId = getResult.recordset[0].User_Id
            }
            console.log('ok')
            res.json(ok)
        }).catch(err => {
            res.json(ok)
        })
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/game_getList', (req, res) => {
    var order = req.body.order
    var query = ``

    if (order == "rating") {
        query = ``
    } else {
        query = `SELECT G.Game_Id, Gyear, Gdescription, Category, Gtitle, Players, PlayTime, Thumbnail, Mname, COUNT(distinct R.Review_Id) as ReviewCount, AVG(distinct R.Grate) as Rate
        FROM
        GAME as G INNER JOIN GAME_MANUFACTURER as M ON G.Manufacturer_Id = M.Manufacturer_Id
                  FULL OUTER JOIN GAME_REVIEW as R ON G.Game_Id = R.Game_Id
                  GROUP BY G.Game_Id, G.Gyear, G.Gdescription, G.Category, G.Gtitle, G.Players, G.PlayTime, G.Thumbnail, M.Mname
                  ORDER BY G.Game_Id ASC`
    }

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "game_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/game_getReview', (req, res) => {
    var gameId = req.body.gameId
    if (!gameId) { 
        res.json(fail)
        return
    }

    var query = `SELECT Uname, Review_Id, Title, Grate
    FROM GAME_REVIEW as R INNER JOIN PLAYER as P ON R.User_Id = P.User_Id WHERE Game_Id = ${gameId}`
    
    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "review_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/group_myinfo', (req, res) => {
    
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }



    var query = `SELECT G.Group_Id, G.Gintroduction, G.Gname, G.IsPublic, G.Goperator_Id, Uname as Operator, Limit, COUNT(M2.Group_Id) as numOfMember
    FROM
    PLAYGROUP as G JOIN PLAYER as P on G.Goperator_Id = P.User_Id 
                   JOIN GROUP_MEMBER as M on G.Group_Id = M.Group_Id AND M.User_Id = ${sess.userId}
                   JOIN GROUP_MEMBER as M2 on G.Group_Id = M2.Group_Id
                   GROUP BY G.Group_Id, Gintroduction, Gname, IsPublic, Goperator_Id, Uname, Limit
                   ORDER BY G.Group_Id ASC;`
    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "group_list" : result.recordset, "myId" : sess.userId.toString()})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/group_exceptlist', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `SELECT G.Group_Id, Gintroduction, Gname, IsPublic, Goperator_Id, Uname as Operator, Limit, COUNT(M.Group_Id) as numOfMember
    FROM
    PLAYGROUP as G JOIN PLAYER as P on G.Goperator_Id = P.User_Id
                   JOIN GROUP_MEMBER as M on G.Group_Id = M.Group_Id
                   GROUP BY G.Group_Id, Gintroduction, Gname, IsPublic, Goperator_Id, Uname, Limit
    EXCEPT
    SELECT G.Group_Id, G.Gintroduction, G.Gname, G.IsPublic, G.Goperator_Id, Uname as Operator, Limit, COUNT(M2.Group_Id) as numOfMember
        FROM
        PLAYGROUP as G JOIN PLAYER as P on G.Goperator_Id = P.User_Id 
                       JOIN GROUP_MEMBER as M on G.Group_Id = M.Group_Id AND M.User_Id = ${sess.userId}
                       JOIN GROUP_MEMBER as M2 on G.Group_Id = M2.Group_Id
                       GROUP BY G.Group_Id, Gintroduction, Gname, IsPublic, Goperator_Id, Uname, Limit
                       ORDER BY G.Group_Id ASC;`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "group_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/group_make', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var name = req.body.name
    var introduction = req.body.introduction
    var limit = req.body.limit
    var ispublic = req.body.ispublic

    var query = `DECLARE @Gname varchar(256);
    SET @Gname = '${name}';
    DECLARE @g_id int;
    
    INSERT INTO PLAYGROUP(Gname, Gintroduction, IsPublic, Limit, Goperator_Id) VALUES('${name}', '${introduction}',${ispublic},${limit},${sess.userId});
    SELECT @g_id = Group_Id FROM PLAYGROUP WHERE Gname = @Gname;
    INSERT INTO GROUP_MEMBER(Group_Id, User_Id) VALUES(@g_id, ${sess.userId});`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/group_part', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var groupId = req.body.groupId
    if (!groupId) {
        res.json(fail)
        return
    }

    var query = `INSERT INTO GROUP_MEMBER(Group_Id, User_Id) VALUES('${groupId}','${sess.userId}');`
    
    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/group_remove', (req, res) => {
    var sess = req.session

    var groupId = req.body.groupId
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `DELETE FROM PLAYGROUP WHERE Group_Id = ${groupId};`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/match_make_grouplist', (req, res) => {
    var sess = req.session
    
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `SELECT G.Group_Id, G.Gname FROM PLAYGROUP as G JOIN PLAYER as P on G.Goperator_Id = P.User_Id AND P.User_Id = ${sess.userId} ORDER BY G.Group_Id ASC;`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "group_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/match_make_gamelist', (req, res) => {
    var sess = req.session

    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `Select Game_Id, Gtitle FROM GAME;`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "game_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/match_make', (req, res) => {
    var sess = req.session

    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = null

    var match_type = req.body.match_type
    var location_type = req.body.location_type

    var name = req.body.name
    var url = req.body.url
    var start_time = req.body.start_time
    var phone = req.body.phone
    var end_time = req.body.end_time
    var addr = req.body.addr
    var latitude = req.body.latitude
    var longitude = req.body.longitude
    var groupId = req.body.groupId
    var location_name = req.body.location_name
    var gameId = req.body.gameId

    if (match_type == "personal") {
        if (location_type == "online") {
            // personal, online
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @match_id_table TABLE(Match_Id int)
            DECLARE @location_id int;
            DECLARE @match_id int;
            
            
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
            
            SELECT @location_id = Location_Id FROM @location_id_table;
            
            INSERT INTO LOCATION_ONLINE(Location_Id ,Location_URL) VALUES(@location_id ,'${url}');
            
            INSERT INTO MATCH_LIST(Competition_Id, Location_Id, Game_Id, Operator_Id,
                                   MStart_time, MEnd_time, Mtitle, Group_Id) OUTPUT INSERTED.Match_Id INTO @match_id_table
                            VALUES(NULL, @location_id, ${gameId}, ${sess.userId}, '${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, '${name}', NULL);
            
            SELECT @match_id = Match_Id FROM @match_id_table;
            
            INSERT INTO MATCH_PART_USER(Match_Id, User_Id) VALUES(@match_id, ${sess.userId});`
        } else if (location_type == "offline") {
            // personal, offline
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @match_id_table TABLE(Match_Id int)
            DECLARE @location_id int;
            DECLARE @match_id int;
            
            
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
            
            SELECT @location_id = Location_Id FROM @location_id_table;
            
            INSERT INTO LOCATION_OFFLINE(Lphone, Laddress, Latitude, Longitude, Location_Id) VALUES('${phone}', '${addr}', ${latitude}, ${longitude}, @location_id);
            
            INSERT INTO MATCH_LIST(Competition_Id, Location_Id, Game_Id, Operator_Id,
                                   MStart_time, MEnd_time, Mtitle, Group_Id) OUTPUT INSERTED.Match_Id INTO @match_id_table
                            VALUES(NULL, @location_id, ${gameId}, ${sess.userId}, '${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, '${name}', NULL);
            
            SELECT @match_id = Match_Id FROM @match_id_table;
            
            INSERT INTO MATCH_PART_USER(Match_Id, User_Id) VALUES(@match_id, ${sess.userId});`
        } else {
            // err
            res.json(fail)
            return 
        }
    } else if (match_type == "group"){
        if (location_type == "online") {
            // group, online
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @match_id_table TABLE(Match_Id int)
            DECLARE @location_id int;
            DECLARE @match_id int;
            
            
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
            
            SELECT @location_id = Location_Id FROM @location_id_table;
            
            INSERT INTO LOCATION_ONLINE(Location_Id ,Location_URL) VALUES(@location_id ,'${url}');
            
            INSERT INTO MATCH_LIST(Competition_Id, Location_Id, Game_Id, Operator_Id,
                                   MStart_time, MEnd_time, Mtitle, Group_Id) OUTPUT INSERTED.Match_Id INTO @match_id_table
                            VALUES(NULL, @location_id, ${gameId}, ${sess.userId}, '${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, '${name}', '${groupId}');
            
            SELECT @match_id = Match_Id FROM @match_id_table;

            INSERT INTO MATCH_PART_USER(Match_Id, User_Id) VALUES(@match_id, ${sess.userId});`
        } else if (location_type == "offline") {
            // group, offline
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @match_id_table TABLE(Match_Id int)
            DECLARE @location_id int;
            DECLARE @match_id int;
            
            
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
            
            SELECT @location_id = Location_Id FROM @location_id_table;
            
            INSERT INTO LOCATION_OFFLINE(Lphone, Laddress, Latitude, Longitude, Location_Id) VALUES('${phone}', '${addr}', ${latitude}, ${longitude}, @location_id);
            
            INSERT INTO MATCH_LIST(Competition_Id, Location_Id, Game_Id, Operator_Id,
                                   MStart_time, MEnd_time, Mtitle, Group_Id) OUTPUT INSERTED.Match_Id INTO @match_id_table
                            VALUES(NULL, @location_id, ${gameId}, ${sess.userId}, '${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, '${name}', '${groupId}');
            
            SELECT @match_id = Match_Id FROM @match_id_table;

            INSERT INTO MATCH_PART_USER(Match_Id, User_Id) VALUES(@match_id, ${sess.userId});`
        } else {
            // err
            res.json(fail)
            return
        }
    } else {
        // err
        res.json(fail)
        return
    }

    console.log(query)

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.post('/match_get', (req, res) => {
    var sess = req.session

    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = null

    var type = req.body.data_type

    if (type == 'personal_partin') {
        query = `SELECT MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname as Operator_Name, COUNT(MPU1.Match_Id) as PartNum, G.Players as MaxLimit
        FROM MATCH_LIST JOIN LOCATION_LIST as L on L.Location_Id = MATCH_LIST.Location_Id
        JOIN PLAYER as P on MATCH_LIST.Operator_Id = P.User_Id
        JOIN GAME as G on G.Game_Id = MATCH_LIST.Game_Id AND MATCH_LIST.Group_Id IS NULL
        JOIN MATCH_PART_USER as MPU1 on MATCH_LIST.Match_Id = MPU1.Match_Id
        WHERE MATCH_LIST.Match_Id IN(
            SELECT MI.Match_Id
            FROM MATCH_PART_USER AS MPU JOIN MATCH_LIST AS MI1 ON MPU.Match_Id=MI1.Match_Id,
                 MATCH_LIST AS MI
            WHERE (MI1.Match_Id=MI.Match_Id AND (MI.MEnd_Time IS NULL OR MI.MEnd_Time > GETDATE()) AND MPU.User_Id=${sess.userId})
        )
        GROUP BY MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname, G.Players
        ORDER BY Match_Id ASC;`
    } else if (type == 'group_partin') {
        query = `SELECT MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname as Operator_Name, COUNT(MPU1.Match_Id) as PartNum, G.Players as MaxLimit
        FROM MATCH_LIST JOIN LOCATION_LIST as L on L.Location_Id = MATCH_LIST.Location_Id
        JOIN PLAYER as P on MATCH_LIST.Operator_Id = P.User_Id
        JOIN GAME as G on G.Game_Id = MATCH_LIST.Game_Id AND MATCH_LIST.Group_Id IS NOT NULL
        JOIN MATCH_PART_USER as MPU1 on MATCH_LIST.Match_Id = MPU1.Match_Id
		JOIN GROUP_MEMBER as GM on MATCH_LIST.Group_Id = GM.Group_Id AND GM.User_Id = P.User_Id
        WHERE MATCH_LIST.Match_Id IN(
            SELECT MI.Match_Id
            FROM MATCH_PART_USER AS MPU JOIN MATCH_LIST AS MI1 ON MPU.Match_Id=MI1.Match_Id,
                 MATCH_LIST AS MI
            WHERE (MI1.Match_Id=MI.Match_Id AND (MI.MEnd_Time IS NULL OR MI.MEnd_Time > GETDATE()) AND MPU.User_Id=${sess.userId})
        )
        GROUP BY MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname, G.Players
        ORDER BY Match_Id ASC;`
    } else if (type == 'personal_available') {
        query = `SELECT MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname as Operator_Name, COUNT(MPU1.Match_Id) as PartNum, G.Players as MaxLimit
        FROM MATCH_LIST JOIN GAME as G on G.Game_Id = MATCH_LIST.Game_Id
		JOIN PLAYER as P on MATCH_LIST.Operator_Id = P.User_Id
		JOIN MATCH_PART_USER as MPU1 on MATCH_LIST.Match_Id = MPU1.Match_Id
		JOIN LOCATION_LIST as L on L.Location_Id = MATCH_LIST.Location_Id
        WHERE MATCH_LIST.Match_Id IN(
			SELECT MPU.Match_Id FROM MATCH_PART_USER as MPU EXCEPT
			SELECT MPU.Match_Id FROM MATCH_PART_USER as MPU WHERE MPU.User_Id = ${sess.userId}
		) AND MATCH_LIST.Group_Id IS NULL AND MATCH_LIST.MStart_time > GETDATE()

		GROUP BY MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname, G.Players
		ORDER BY Match_Id ASC`
    } else if (type == 'group_available') {
        query = `SELECT MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname as Operator_Name, COUNT(MPU.Match_Id) as PartNum, G.Players as MaxLimit
        FROM MATCH_LIST JOIN GAME as G on G.Game_Id = MATCH_LIST.Game_Id
		JOIN PLAYER as P on MATCH_LIST.Operator_Id = P.User_Id
		JOIN MATCH_PART_USER as MPU on MATCH_LIST.Match_Id = MPU.Match_Id
		JOIN LOCATION_LIST as L on L.Location_Id = MATCH_LIST.Location_Id
		JOIN GROUP_MEMBER as GM on GM.Group_Id=MATCH_LIST.Group_Id AND GM.User_Id=${sess.userId}
        WHERE MATCH_LIST.Match_Id IN(
			SELECT MPU.Match_Id FROM MATCH_PART_USER as MPU EXCEPT
			SELECT MPU.Match_Id FROM MATCH_PART_USER as MPU WHERE MPU.User_Id = ${sess.userId}
		) AND MATCH_LIST.MEnd_time IS NULL AND MATCH_LIST.MStart_time > GETDATE() AND MPU.User_Id != 1 AND MATCH_LIST.Group_ID IS NOT NULL

		GROUP BY MATCH_LIST.Match_Id, MATCH_LIST.Mtitle, G.Gtitle, L.Location_Name, MATCH_LIST.MStart_Time, MATCH_LIST.MEnd_Time, P.Uname, G.Players
		ORDER BY Match_Id ASC;`
    } else {
        // err
        res.json(fail)
        return
    }

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)

        var d = new Date()

        for (var i = 0; i < result.recordset.length; i++) {
            if (result.recordset[i].MStart_Time - d > 0) {

                // 예정
                result.recordset[i].state = '0';
            } else {
                if (result.recordset[i].MEnd_Time) {
                    if (result.recordset[i].MEnd_Time - d < 0) {
                        // 종료
                        result.recordset[i].state = '2';
                    } else {
                        // 진행중
                        result.recordset[i].state = '1';
                    }
                } else {
                    // 진행중
                    result.recordset[i].state = '1';
                }
            }
            if (result.recordset[i].MEnd_Time) {
                var start_temp = result.recordset[i].MEnd_Time.toISOString()

            result.recordset[i].MEnd_Time = start_temp.substring(0, 10) + ' ' + start_temp.substring(11, 19)
            }
            var start_temp = result.recordset[i].MStart_Time.toISOString()

            result.recordset[i].MStart_Time = start_temp.substring(0, 10) + ' ' + start_temp.substring(11, 19)
            //2018-12-19T15:00:00.000Z
        }

        res.json({"result" : "ok", "match_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })
})

app.post('/cpp_make', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = ``
    var cpp_type = req.body.cpp_type
    var location_type = req.body.location_type


    var name = req.body.name
    var url = req.body.url
    var start_time = req.body.start_time
    var phone = req.body.phone
    var end_time = req.body.end_time
    var addr = req.body.addr
    var latitude = req.body.latitude
    var longitude = req.body.longitude
    var groupId = req.body.groupId
    var location_name = req.body.location_name
    var gameId = req.body.gameId


    if (cpp_type == 'personal') {
        if (location_type == 'online') {
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @competition_id_table TABLE(Competition_Id int)
            DECLARE @location_id int;
            DECLARE @competition_id int;
                        
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
                        
            SELECT @location_id = Location_Id FROM @location_id_table;
             
            INSERT INTO LOCATION_ONLINE(Location_Id ,Location_URL) VALUES(@location_id ,'${url}');
            
            INSERT INTO COMPETITION(Cstart_time, Cend_time, Location_Id, Operator_Id, Game_Id, Ctitle, Group_Id) OUTPUT INSERTED.Competition_Id
            INTO @competition_id_table VALUES ('${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, @location_id, ${sess.userId}, ${gameId}, '${name}', NULL);
            
            SELECT @competition_id = Competition_Id FROM @competition_id_table;
            
            INSERT INTO COMPETITION_PART_USER(Competition_Id, User_Id) VALUES(@competition_id, ${sess.userId});`
        } else if (location_type == 'offline') {
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @competition_id_table TABLE(Competition_Id int)
            DECLARE @location_id int;
            DECLARE @competition_id int;
                        
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
                        
            SELECT @location_id = Location_Id FROM @location_id_table;
             
            INSERT INTO LOCATION_OFFLINE(Lphone, Laddress, Latitude, Longitude, Location_Id) VALUES('${phone}', '${addr}', ${latitude}, ${longitude}, @location_id);
            
            INSERT INTO COMPETITION(Cstart_time, Cend_time, Location_Id, Operator_Id, Game_Id, Ctitle, Group_Id) OUTPUT INSERTED.Competition_Id
            INTO @competition_id_table VALUES ('${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, @location_id, ${sess.userId}, ${gameId}, '${name}', NULL);
            
            SELECT @competition_id = Competition_Id FROM @competition_id_table;
            
            INSERT INTO COMPETITION_PART_USER(Competition_Id, User_Id) VALUES(@competition_id, ${sess.userId});
            
            `
        } else { 
            res.json(fail)
            return
        }
    } else if (cpp_type == 'group') {
        if (location_type == 'online') {
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @competition_id_table TABLE(Competition_Id int)
            DECLARE @location_id int;
            DECLARE @competition_id int;
                        
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
                        
            SELECT @location_id = Location_Id FROM @location_id_table;
             
            INSERT INTO LOCATION_ONLINE(Location_Id ,Location_URL) VALUES(@location_id ,'${url}');
            
            INSERT INTO COMPETITION(Cstart_time, Cend_time, Location_Id, Operator_Id, Game_Id, Ctitle, Group_Id) OUTPUT INSERTED.Competition_Id
            INTO @competition_id_table VALUES ('${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, @location_id, ${sess.userId}, ${gameId}, '${name}', ${groupId});
            
            SELECT @competition_id = Competition_Id FROM @competition_id_table;
            
            INSERT INTO COMPETITION_PART_USER(Competition_Id, User_Id) VALUES(@competition_id, ${sess.userId});
            
            `
        } else if (location_type == 'offline') {
            query = `DECLARE @location_id_table TABLE(Location_Id int, Location_Name varchar(256));
            DECLARE @competition_id_table TABLE(Competition_Id int)
            DECLARE @location_id int;
            DECLARE @competition_id int;
                        
            INSERT INTO LOCATION_LIST(Location_Name) OUTPUT INSERTED.Location_Id, INSERTED.Location_Name INTO @location_id_table VALUES('${location_name}');
                        
            SELECT @location_id = Location_Id FROM @location_id_table;
             
            INSERT INTO LOCATION_OFFLINE(Lphone, Laddress, Latitude, Longitude, Location_Id) VALUES('${phone}', '${addr}', ${latitude}, ${longitude}, @location_id);
            
            INSERT INTO COMPETITION(Cstart_time, Cend_time, Location_Id, Operator_Id, Game_Id, Ctitle, Group_Id) OUTPUT INSERTED.Competition_Id
            INTO @competition_id_table VALUES ('${start_time}', ${end_time == '' ? null : (`'` + end_time + `'`)}, @location_id, ${sess.userId}, ${gameId}, '${name}', ${groupId});
            
            SELECT @competition_id = Competition_Id FROM @competition_id_table;
            
            INSERT INTO COMPETITION_PART_USER(Competition_Id, User_Id) VALUES(@competition_id, ${sess.userId});
            
            `
        } else {
            res.json(fail)
            return
        }
    } else {
        // err

        res.json(fail)
        return
    }

    console.log(query)

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.post('/match_part', (req, res) => {
    var sess = req.session
    var matchId = req.body.matchId

    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `INSERT INTO MATCH_PART_USER(User_Id, Match_Id) VALUES(${sess.userId}, ${matchId});`

    console.log(query)

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json(ok)
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.post('/mypage_latest_match', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `SELECT top(5) MATCH_LIST.Mtitle, MATCH_LIST.MStart_time, MATCH_LIST.MEnd_time, MATCH_WINNER.User_Id
    FROM MATCH_LIST JOIN MATCH_WINNER ON MATCH_WINNER.Match_Id= MATCH_LIST.Match_Id 
    WHERE MATCH_LIST.Match_Id IN(
       SELECT MPU.Match_Id 
       FROM (MATCH_PART_USER AS MPU JOIN MATCH_LIST AS ML
       ON MPU.Match_Id = ML.Match_Id) 
       WHERE MPU.User_Id=${sess.userId} AND ML.MStart_time<GETDATE()
    )
    ORDER BY MATCH_LIST.MStart_time desc;`

    console.log(query)

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)

        var d = new Date()

        for (var i = 0; i < result.recordset.length; i++) {
            result.recordset[i].win = '-'
            if (result.recordset[i].MStart_time - d > 0) {

                // 예정
                result.recordset[i].state = '0';
            } else {
                if (result.recordset[i].MEnd_time) {
                    if (result.recordset[i].MEnd_time - d < 0) {
                        // 종료
                        result.recordset[i].state = '2';
                        if (result.recordset[i].User_Id == sess.userId) {
                            result.recordset[i].win = '승'
                        } else {
                            result.recordset[i].win = '패'
                        }
                    } else {
                        // 진행중
                        result.recordset[i].state = '1';
                    }
                } else {
                    // 진행중
                    result.recordset[i].state = '1';
                }
            }
            var start_temp = result.recordset[i].MStart_time.toISOString()

            result.recordset[i].MStart_time = start_temp.substring(0, 10) + ' ' + start_temp.substring(11, 19)
            //2018-12-19T15:00:00.000Z
        }

        res.json({"result" : "ok", "match_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.post('/mypage_latest_game', (req, res) => {
    var sess = req.session
    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = `SELECT top (5) GAME.Gtitle, MATCH_LIST.MStart_time
    FROM GAME JOIN MATCH_LIST ON GAME.Game_Id =MATCH_LIST.Game_Id
    WHERE GAME.Game_Id IN
    (
       SELECT G.Game_Id
        FROM (MATCH_LIST AS ML JOIN MATCH_PART_USER AS MPU
        ON ML.Match_Id=ML.Match_Id) JOIN GAME AS G ON ML.Game_Id=G.Game_Id
       WHERE MPU.User_Id=${sess.userId} AND ML.MStart_time<GETDATE()
    )
    ORDER BY MATCH_LIST.MStart_time desc;`

    console.log(query)

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)

        for (var i = 0; i < result.recordset.length; i++) {
            var start_temp = result.recordset[i].MStart_time.toISOString()

            result.recordset[i].MStart_time = start_temp.substring(0, 10) + ' ' + start_temp.substring(11, 19)
            //2018-12-19T15:00:00.000Z
        }

        res.json({"result" : "ok", "game_list" : result.recordset})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.post('/mypage_getCount', (req, res) => {
    var sess = req.session

    if (!sess.userId) {
        res.json(fail)
        return
    }

    var query = 
    `DECLARE @numOfMatch int;
    DECLARE @winCount int;
    
    SELECT @numOfMatch = COUNT(MATCH_LIST.Match_Id)
    FROM MATCH_LIST
    WHERE MATCH_LIST.Match_Id IN
    (
       SELECT MPU.Match_Id    
       FROM MATCH_PART_USER AS MPU JOIN MATCH_LIST AS ML 
       ON MPU.Match_Id=ML.Match_Id
       WHERE MPU.User_Id=${sess.userId} AND ML.MEnd_time<GETDATE()
    );
    
    SELECT @winCount = COUNT(MATCH_LIST.Match_Id)
    FROM MATCH_LIST
    WHERE MATCH_LIST.Match_Id IN
    (
       SELECT MPU.Match_Id    
       FROM (MATCH_PART_USER AS MPU JOIN MATCH_LIST AS ML 
       ON MPU.Match_Id=ML.Match_Id) JOIN MATCH_WINNER AS MW
       ON MPU.Match_Id=MW.Match_Id
       WHERE MW.User_id=${sess.userId} AND ML.MEnd_time<GETDATE()
    );
    
    SELECT @numOfMatch as 'NumOfMatch', @winCount as 'WinCount', @numOfMatch - @winCount as 'LoseCount';`

    new sql.ConnectionPool(config).connect().then((pool) => {
        return pool.query(query)
    }).then(result => {
        console.log(result)
        res.json({"result" : "ok", "count" : result.recordset[0]})
    }).catch(err => {
        console.log(err)
        res.json(fail)
    })

    console.log(req.body)
})

app.listen(port, () => console.log('server listening on port : ' + port.toString()))
