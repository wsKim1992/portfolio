var host;
var port;
var socket;

$(function(){
    $('#connectButton').bind('click', function(e){
        println('connectButton이 클릭되었습니다.');
        host = $('#hostInput').val();
        port = $('#portInput').val();

        connectToServer();
    });
});

function connectToServer(){
    var options = {'forceNew' : true};
    var url = 'http://' +  host + ":" + port;
    socket = io.connect(url, options);

    socket.on('connect', function(){
        println('웹 소켓 서버에 연결되었습니다. : ' + url);
    });

    socket.on('disconnect', function(){
        println('웹 소켓 연결이 종료되었습니다.');
    });

    $('#messageButton').bind('click', function(e){
        socket.on('message', function(msg){
            println('메시지 수신: ' + msg);
        });
    });
}

function println(data){
    console.log(data);
    $('#result').append('<p>' + data + '</p>');
}