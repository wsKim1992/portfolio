var createError = require('http-errors');
var express = require('express');
//var http = require('http').Server(express);
var path = require('path');
//var cookieParser = require('cookie-parser');
var logger = require('morgan');
//var socketio = require('socket.io');
var crypto = require('crypto');
var expressSession = require('express-session');
module.exports = genuuid;

function genuuid(callback) {
    if (typeof(callback) !== 'function') {
        return uuidFromBytes(crypto.randomBytes(16));
    }

    crypto.randomBytes(16, function(err, rnd) {
        if (err) return callback(err);
        callback(null, uuidFromBytes(rnd));
    });
}

function uuidFromBytes(rnd) {
    rnd[6] = (rnd[6] & 0x0f) | 0x40;
    rnd[8] = (rnd[8] & 0x3f) | 0x80;
    rnd = rnd.toString('hex').match(/(.{8})(.{4})(.{4})(.{4})(.{12})/);
    rnd.shift();
    return rnd.join('-');
}

var cors = require('cors');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// const mysql = require('mysql');
// const dbconfig = require('./config/database.js');
//
// let db = mysql.createConnection(dbconfig);
//
// db.connect({}, function(err){
//     if(!err)
//         console.log('DB 연결이 성공적으로 연결되었습니다.');
//     else
//         console.log('DB 연결 실패: ' + err);
// });
//
// db.query('SELECT * FROM hollys_board', function(err ,data){
//     if(err) console.log('err 발생 : ' + err);
//     else console.log(data);
// });
//
// db.end({}, function(err){
//     if(!err)
//         console.log('DB 연결이 성공적으로 종료되었습니다.');
//     else
//         console.log('DB 연결종료 실패: ' + err);
// });


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(cors());
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(expressSession({
    genid: function(req){
        return genuuid() // use UUIDs for session IDs
    },
    secret: 'Bitcoin is a scam',//session을 암호화 하여 저장
    resave: true, // ????//세션을 언제나 저장할 지 정하는 값.
    saveUninitialized: true, //, // ????//세션이 저장되기 전에 uninitialized 상태로 만듦
    cookie: { maxAge: 1000* 60 * 60 //쿠키 유효시간 1시간
    }
}));


app.use('/', indexRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});


// var io = socketio.listen(server);
// console.log('[Socket.io] Ready to accept requests');
//
// io.sockets.on('connection', function(socket){
//     console.log('connection info : ', socket.request.connection._peername);
//     // 소켓 객체이 클라이언트 호스트, 포트 정보 속성으로 추가
//     socket.remoteAddress = socket.request.connection._peername.address;
//     socket.remotePort =  socket.request.connection._peername.port;
//
//     socket.on('message', function(message){
//        console.log('[Socket.io] message 이벤트를 받았습니다');
//        console.dir(message);
//
//        if(message.recepient == 'ALL'){
//            console.dir('나를 포함한 모든 클라이언트에게 message 이벤트를 전송합니다.');
//            io.sockets.emit('message', message);
//        }
//     });
// });

module.exports = app;
