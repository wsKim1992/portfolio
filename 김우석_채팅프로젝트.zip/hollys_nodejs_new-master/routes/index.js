var express = require('express');
var jssha256 = require('js-sha256').sha256;
var router = express.Router();

var crypto = require('crypto');
//const app = require('../app');

// Middleware

const mysql = require('mysql');
const dbConfig = require('./../config/database.js');

// var usernameResult = {
//     set current(str){
//         this.data = str;
//     },
//     data: ''
// }
//우석 파트 시작
router.get('/myPage', (req, res) => {
    res.render('myPage', {});
})

router.get('/registPage', function (req, res, next) {
    console.log(req.session.storedSID);
    req.session.recentPage = '/registPage';
    if (req.session.storedSID == undefined) {
        return res.render('login', {username: '', message: '계정을 입력하세요'});
    } else {
        return res.render('registPage', {});
    }
});

router.get("/login", (req, res) => {
    res.render("login", {username: '', message: ''});
})

router.post('/Board/login', (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    let category = req.body.category;
    let page_num = req.body.cur_page_num;
    let search_sql = 'SELECT * FROM members where username=?';
    let cipher = crypto.createHash('sha256');
    let db = mysql.createConnection(dbConfig);
    db.connect({}, (err) => {
        if (!err)
            console.log("DB 연결 성공");
        else
            console.log("DB 연결 실패");
    })
    req.session.recentPage = '/Board/' + category + '/' + page_num;
    if (password == undefined || username == undefined) {
        return res.redirect('/login');
    }
    /*crypto.randomBytes(64,(err,buf)=>{
        crypto.pbkdf2(password,buf.toString('base64'), 100000 , 64 ,'sha512',(err,key)=>{
            res.send(key.toString('base64'));
        })
    })*/
    session = req.session;
    if (session.storedSID != undefined) {
        res.redirect('/Board/' + category + '/' + page_num);
    }
    db.query(search_sql, [username], (err, data) => {
        if (err)
            console.log(err);
        if (data[0] == undefined) {
            console.log('계정이 존재하지 않음.')
            return res.render('login', {username: '', message: '이메일 주소가 존재하지 않습니다.'});
        }
        let user = data[0];
        let PW = cipher.update(password).digest('hex');
        console.log(PW);
        if (PW == user.password) {
            req.session.storedSID = session.id;
            req.session.storedUsername = user.username;
            req.session.storedUserId = user.id;
            req.session.storedNickname = user.nickname;
            //req.session.recentPage = '/Board/' + category + '/' + page_num;
            console.log('sessionid:' + req.session.storedSID);
            console.log('sessionUsername:' + req.session.storedUsername);
            res.redirect(req.session.recentPage);
        } else {
            console.log('비밀번호 불일치');
            res.render('login', {username: '', message: '비밀번호가 일치하지 않습니다'});
        }
    })
})


router.post('/registed', (req, res) => {
    //let time = new Date();
    let username = req.session.storedUsername;
    let search_mem_id_sql = 'select id from members where username=?';
    let chat_room_name = req.body.title;
    let category = req.body.category;
    let chat_time = req.body.sethour * 3600 + req.body.setminutes * 60;
    let speaking_time = req.body.settingSpeakingTime * 60;
    let sql = 'INSERT INTO chatroom(category,name,isEnd,speaking_time,chat_time,isStarted,createId) VALUES(?,?,?,?,?,?,?)';
    var ip = (
        req.headers['x-forwarded-for'] ||
        req.connection.remoteAddress ||
        req.socket.remoteAddress ||
        req.connection.socket.remoteAddress).split(",")[0];

    let db = mysql.createConnection(dbConfig);
    db.connect({}, (err) => {
        if (!err)
            console.log('DB 연결이 성공적으로 연결되었습니다.');
        else
            console.log('DB 연결 실패: ' + err);
    })
    db.query(search_mem_id_sql, [username], (err, data) => {
        if (!err) {
            db.query(sql, [category, chat_room_name, 0, speaking_time, chat_time, 0, data[0].id], (err, data) => {
                if (!err) {
                    console.log('data 저장 완료')
                } else {
                    console.log(err);
                }
                console.log("접속 ip 주소: " + ip);

                res.redirect('/Board/' + category + '/1');
            })
        }
        else
            console.log(err);
    })
})

router.get('/Board', (req, res) => {
    res.render('myPage', {});
})

router.get('/Board/:category/:page/', (req, res) => {
    let category = req.params.category;
    var cur_page_Num = 0;

    if (req.params.page == undefined) {
        cur_page_Num = 1;
    } else {
        cur_page_Num = req.params.page;
    }
    console.log(cur_page_Num);

    var total_chat_room;
    const chat_room_per_page = 5;
    var total_pages;
    var pages_per_set = 10;
    var total_set;
    var cur_set;
    var start_page;
    var end_page;

    let count = 'SELECT COUNT(*) as Cnt FROM chatroom WHERE category=?';

    let db = mysql.createConnection(dbConfig);
    db.connect({}, (err) => {
        if (!err)
            console.log("DB 연결 성공");
        else
            console.log("DB 연결 실패");
    })

    db.query(count, [category], (err, data) => {
        total_chat_room = (JSON.stringify(data).replace('[','').replace(']','').replace('{','').replace('}','')).substring(6);
        console.log("total_chat_room:" + total_chat_room);
        if (total_chat_room == 0) {
            total_chat_room = 1;
        }
        total_pages = Math.ceil(total_chat_room / chat_room_per_page);
        total_set = Math.ceil(total_pages / pages_per_set);
        cur_set = Math.ceil(cur_page_Num / pages_per_set);
        start_page = ((cur_set - 1) * pages_per_set) + 1;
        if (cur_set < total_set) {
            end_page = (start_page + pages_per_set) - 1;
        } else {
            end_page = Math.ceil(total_chat_room / chat_room_per_page);
        }

        let paging_Result = {
            "total_chat_room_num": total_chat_room,
            "chat_room_per_page": chat_room_per_page,
            "total_pages": total_pages,
            "pages_per_set": pages_per_set,
            "total_set": total_set,
            "cur_set": cur_set,
            "start_page": start_page,
            "end_page": end_page,
            "cur_page_Num": cur_page_Num
        };

        console.log(paging_Result);

        var picked_up_data = [];
        var j = 0;
        var start_chat_room_idx;
        var end_chat_room_idx;

        let db = mysql.createConnection(dbConfig);
        db.connect({}, (err) => {
            if (!err)
                console.log('DB 연결이 성공적으로 연결되었습니다.');
            else
                console.log('DB 연결 실패: ' + err);
        })
        start_chat_room_idx = (cur_page_Num - 1) * chat_room_per_page;
        let selectAllSql = 'SELECT * FROM chatroom WHERE category=? AND isEnd=0 ORDER BY id LIMIT ? OFFSET ?';
        db.query(selectAllSql, [category,chat_room_per_page,start_chat_room_idx], (err, data) => {
            console.log(category + " 열람됨!")
            console.log(data)
            if (cur_page_Num == end_page){
                end_chat_room_idx = data.length - 1;
            } else {
                end_chat_room_idx = cur_page_Num * chat_room_per_page - 1;
            }
            for (var i = start_chat_room_idx; i <= end_chat_room_idx; i++) {
                picked_up_data[j++] = data[i];
            }
            console.log(start_chat_room_idx);
            //console.log(end_chat_room_idx);

            let display_log_in_div;
            let display_log_out_div;
            let is_session_exist = new Boolean(false);

            if (req.session.storedSID) {
                is_session_exist = true;
                display_log_in_div = 'none';
                req.session.recentPage = '/Board/' + category + '/' + cur_page_Num;
            } else {
                display_log_out_div = 'none';
                is_session_exist = false;
            }
            let enable_before;
            let enable_next;
            if (start_page == 1) {
                enable_before = 'none';
            }
            if (end_page % 10 != 0 || total_pages < 10) {
                enable_next = 'none';
            }
            res.render('Board', {
                //user_id: '',
                //user_nickname: '',
                is_session_exist: is_session_exist,
                categoryName: category,
                rows: data,
                paging_Result: paging_Result,
                display_log_in: display_log_in_div,
                display_log_out: display_log_out_div,
                enable_before: enable_before,
                enable_next: enable_next
            })
        })
    })
})

router.get('/real_chat', (req, res) => {
    res.render('real_chat', {});
})
//우석파트 끝

//은표파트 시작
/* GET home page. */
router.get('/index', function (req, res, next) {
    res.render('index', {title: '사망토론 :: MAIN'});
    // res.redirect('/login');
});

router.get('/chitchat/:chat_room_idx/:chat_room_name/:participate', (req, res) => {
    let chat_room_idx = req.params.chat_room_idx;
    let chat_room_name = req.params.chat_room_name;
    let participate = req.params.participate;
    let session = req.session;
    let db = mysql.createConnection(dbConfig);

    if (participate == 'participate') {//토론 참가일 경우
        if (session.storedSID == undefined || session.storedUsername == undefined) {// 토론에 참가하려는데 로그인이 안되었을 때
            session.recentPage='/chitchat/'+chat_room_idx+'/'+chat_room_name+'/'+participate;
            res.render('login', {username: '', message: '채팅에 참가 하기 위해선 로그인을 해야 합니다.'})
        } else {//로그인 되었을 때;
            let username = req.session.storedUsername;
            let userNickname = req.session.storedNickname;
            let userId = req.session.storedUserId;
            console.log(username);
            let query_count_participate = 'select c.isStarted,c.chat_time,c.speaking_time from chatroom as c where c.id=?';
            db.query(query_count_participate,[chat_room_idx],(err,data)=> {
                let isStarted=data[0].isStarted;
                let chat_time=data[0].chat_time;
                let speaking_time=data[0].speaking_time;

                if(err){return console.log(err);}
                if(isStarted) {
                    return res.redirect(session.recentPage);
                }
                session.recentPage = '/chitchat' + '/' + chat_room_idx + '/' + chat_room_name + '/' + participate;
                let insert_query = 'INSERT INTO participate_chat(user_id,chatroom_id) VALUES(?,?)';
                db.query(insert_query, [userId, chat_room_idx], (err, result) => {
                    if (!err) {
                        console.log(userNickname + '님께서' + chat_room_idx + '번째 토론방에 참가함!');
                        res.render('chitchat', {
                            userId:userId,
                            chat_room_idx: chat_room_idx,
                            chat_room_name: chat_room_name,
                            participate: participate,
                            user_nickname: userNickname,
                            chat_time:chat_time,
                            speaking_time:speaking_time
                        });
                    }
                    else console.log("err!");
                })
            })
        }
    }else if (participate == 'spectate') {//참여 형태가 관전일 경우
        let userId='';
        let user_nickname='';
        let get_time_sql='SELECT chat_time,speaking_time FROM chatroom WHERE id=?';
        if (session.storedSID == undefined || session.storedUsername == undefined) {// 참여 형태가 관전인데 로그인이 안되어 있을 경우
            console.log('관전 비로그인');
            userId='';
            user_nickname='';
        }else {//로그인 되어 있을 경우
            userId=req.session.storedUserId;
            user_nickname=req.session.storedNickname;
            session.recentPage = '/chitchat' + '/' + chat_room_idx + '/' + chat_room_name + '/' + participate;
            console.log('관전 로그인');
            /*
            res.render('chitchat', {
                chat_room_idx: chat_room_idx,
                chat_room_name: chat_room_name,
                participate: participate,
                user_nickname: session.storedNickname
            })*/
        }
        db.query(get_time_sql,[chat_room_idx],(err,data)=>{
            res.render('chitchat', {
                userId: userId,
                chat_room_idx: chat_room_idx,
                chat_room_name: chat_room_name,
                participate: participate,
                user_nickname: user_nickname,
                chat_time: data[0].chat_time,
                speaking_time: data[0].speaking_time
            })
        })
    }
    //chitchat 에 embeded 되어야할 변수들
});

router.get('/logout', function (req, res, next) {
    /** 현재 세션을 파괴하는 함수, 세션 자체를 파괴해야 하는지
     *  storedId, storedSID 만 따로 파괴해야 하는지 추가검증 필요 */
        //console.log(req.session.storedUsername);
        //console.log(req.session.id);
        //console.log(req.session.recentPage);
    let recentPage = req.session.recentPage;
    req.session.destroy(function (err) {
        if (err) throw err;
        res.redirect(recentPage);
    });
});

router.get('/login', function (req, res, next) {
    if (req.session.storedSID == undefined || req.session.storedUsername == undefined)
        res.render('login', {username: '', message: ''});
    else
        res.redirect(req.session.recentPage);
});

router.post('/login', function (req, res, next) {
    let _username = req.body.username;
    //_password = jssha256(req.body.password);
    cipher = crypto.createHash('sha256');
    cipher.update(req.body.password);
    let _password = cipher.digest('hex');
    console.dir('유저네임: ' + _username + ', 비밀번호: ' + _password);

    let db = mysql.createConnection(dbConfig);

    db.connect({}, function (err) {
        if (!err)
            console.log('DB 연결이 성공적으로 연결되었습니다.');
        else
            console.log('DB 연결 실패: ' + err);
    });
    db.query('SELECT * FROM members WHERE username = ' + mysql.escape(_username) + 'AND password = ' + mysql.escape(_password), function (err, data) {
        if (err) console.log('err 발생 : ' + err);
        else {
            //let _DATA = (JSON.stringify(data).substring(13)).substring(0, 1)
            if (data[0] != undefined) {
                console.log('[Login Attempt] Account validation succeeded');
                // req.session.currentAccount = _username;
                ssn = req.session;
                ssn.storedSID = req.session.id;
                ssn.storedUsername = _username;
                ssn.storedUserId = data[0].id;
                ssn.storedNickname = data[0].nickname;
                if (req.session.recentPage == undefined) {
                    res.render('myPage', {});
                } else {
                    res.redirect(req.session.recentPage);
                }
            }
            else {
                console.log('[Login Attempt] Account validation failed');
                res.render('login', {username: _username, message: '로그인에 실패했습니다. 이메일 및 비밀번호를 확인해주세요.'});
            }
        }
    });
});

router.get('/signup', function (req, res, next) {
    /* Initialize  */
    var nnRegex = new RegExp('^[\\wㄱ-ㅎㅏ-ㅣ가-힣]{4,12}$');
    console.log(nnRegex.test('닝기리씨발'));

    res.render('signup',
        {
            title: '사망토론 :: SIGNUP',
            username: '',
            realname: '',
            nickname: '',
            phone: '',
            message: ''
        });
});

router.post('/signup', function (req, res, next) {
    /* Save current contents from form POST request */

    let db = mysql.createConnection(dbConfig);

    connectToDB(db);

    var current = {
        username: req.body.username,
        realname: req.body.realname,
        nickname: req.body.nickname,
        phone: req.body.phone,
        gender: req.body.gender
    };
    let password = req.body.password;
    let passwordConfirm = req.body.passwordConfirm;
    //password = req.param('password');
    //passwordConfirm = req.param('passwordConfirm');

    /** Username Validation Check
     *  1. length ( 8-100; [5++] @ [3++].[2++] )
     *  2. rules (e.g. [@ .], [Only written in English & numeral words])
     *  3. Whether username already exists
     * */
    function usernameCheck(callback) {
        pattern = new RegExp('[0-9a-zA-Z]+(.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$');
        if (!pattern.test(current.username)) {
            console.log('이메일 주소 Regex 형식을 준수하지 않음.');
            res.render('signup',
                {
                    title: '사망토론 :: SIGNUP',
                    username: '',
                    realname: current.realname,
                    nickname: current.nickname,
                    phone: current.phone,
                    message: '이메일 형식을 준수해주세요.'
                });
        }

        db.query('SELECT count(*) FROM members WHERE username = ' + mysql.escape(current.username), function (err, data) {
            if (err) {
                console.log('err 발생 : ' + err);
            }
            else {
                tmp = (JSON.stringify(data).substring(13)).substring(0, 1);
                console.log(tmp);
                if (tmp != 0) {
                    console.log('이미 존재하는 이메일 주소.');
                    res.render('signup',
                        {
                            title: '사망토론 :: SIGNUP',
                            username: '',
                            realname: current.realname,
                            nickname: current.nickname,
                            phone: current.phone,
                            gender: current.gender,
                            message: '이미 존재하는 이메일 주소 입니다.'
                        });
                } // End of IF statement
            }
        });
    }

    function passwordCheck(callback) {
        // var pwLength = _password.length;
        /** 최소 8자, 최대 30자, 특수문자 허용, 대소문자 구분, 최소 한 자리의 숫자, 대문자, 소문자, 특수문자가 들어가야 함 */
        var pwRegex = new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,30}$');

        if (password != passwordConfirm || passwordConfirm != password) {
            console.log('비밀번호 매칭 실패!');
            res.render('signup',
                {
                    title: '사망토론 :: SIGNUP',
                    username: current.username,
                    realname: current.realname,
                    nickname: current.nickname,
                    phone: current.phone,
                    message: '비밀번호가 서로 다릅니다.'
                });
        }
        if (!pwRegex.test(password)) {
            console.log('비밀번호 형식을 준수하지 않음!');
            res.render('signup',
                {
                    title: '사망토론 :: SIGNUP',
                    username: current.username,
                    realname: current.realname,
                    nickname: current.nickname,
                    phone: current.phone,
                    message: '비밀번호 규칙을 준수해주세요.'
                });
        }
    }

    function nicknameCheck(callback) {
        /** 1) 한글, 영문 대소문자, 숫자; 특수문자 포함 불가. 길이 최소 4자, 최대 16자
         *  2) 중복확인
         * */
            // 1
        var nnRegex = new RegExp('^[\\w\\Wㄱ-ㅎㅏ-ㅣ가-힣]{4,12}$');
        console.log(nnRegex.test('닝기리!씨발'));

        // 2
        db.query('SELECT count(*) FROM members WHERE nickname = ' + mysql.escape(current.nickname), function (err, data) {
            if (err) {
                console.log('err 발생 : ' + err);
            }
            else {
                tmp = (JSON.stringify(data).substring(13)).substring(0, 1);
                console.log(tmp);
                if (tmp != 0) {
                    console.log('이미 존재하는 닉네임.');
                    res.render('signup',
                        {
                            title: '사망토론 :: SIGNUP',
                            username: '',
                            realname: current.realname,
                            nickname: current.nickname,
                            phone: current.phone,
                            message: '이미 존재하는 닉네임 입니다.'
                        });
                } // End of IF statement
            }
        });
    }

    function realnameCheck(callback) {
        /** 1) 한글만
         *  2) 최소 2자, 최대 6자
         * */


    }

    usernameCheck();
    passwordCheck();
    nicknameCheck();
    realnameCheck();

    const cipher = crypto.createHash('sha256');
    let PW = cipher.update(password).digest('hex');
    let insert_sql = "INSERT INTO members(username,password,realname,nickname,phone,gender) VALUES(?,?,?,?,?,?)";
    db.query(insert_sql, [current.username, PW.toString(), current.realname, current.nickname, current.phone, current.gender], (err, data) => {
        if (err)
            console.log(err);
        else
            console.log('DB입력 성공');
        res.redirect('/login');
    });


    // var today = new Date();
    // var values = [current.username, _password, current.nickname, current.phone, today, '127.0.0.1', today, '127.0.0.1'];
    // var sql = 'INSERT INTO hollys_member (username, password, nickname, phone, regdate, reg_ip, last_login_date, last_login_ip) VALUES (' + mysql.escape(values)+ ')';
    // db.query(sql, function(err, result){
    //     if(err) throw err;
    //     else console.log('DB 삽입 성공!!!');
    // });

    disconnectToDB(db);

    // res.redirect('/login', {});
    // usernameResult.current = data[0].username.toString('utf8');

});

router.get('/tabula', function (req, res, next) {
    res.render('tabula', {title: '사망토론 :: 타뷸라의 늑대'});
});

router.post('/accountvalid', function (req, res, next) {
    // usernameResult.current = '';

    var username = req.param('username');
    let db = mysql.createConnection(dbConfig);

    db.connect({}, function (err) {
        if (!err)
            console.log('DB 연결이 성공적으로 연결되었습니다.');
        else
            console.log('DB 연결 실패: ' + err);
    });

    db.query('SELECT * FROM members WHERE username = ' + mysql.escape(username), function (err, data) {
        if (err) console.log('err 발생 : ' + err);
        else {
            console.log(data);
            if (data == '')
                res.send({status: 0})
            else
                res.send({status: 1})
        }
        // usernameResult.current = data[0].username.toString('utf8');
    });

    db.end({}, function (err) {
        if (!err) {
            console.log('DB 연결이 성공적으로 종료되었습니다.');
            // console.log('유저네임: ' + usernameResult.data);
        }
        else
            console.log('DB 연결종료 실패: ' + err);
    });
});

router.get('/ssc', function (req, res, next) {
    /** @namespace req.session.storedSID*/
    storedSID = req.session.storedSID;
    /** @namespace req.session.storedUsername*/
    storedUsername = req.session.storedUsername;
    if (storedSID == undefined || storedUsername == undefined)
        message = 'Session is not valid. Please login again.';
    else
        message = 'Session confirmed.';
    res.render('ssc', {storedSID: storedSID, storedUsername: storedUsername, message: message});
});

router.get('/test', function (req, res) {
    var app = new Vue({
        el: '#app',
        data: {
            message: '안녕하세요 Vue!'
        }
    })
    res.render('test', {app: app});
});

router.get('/testpage', function (req, res) {
    sid = req.session.storedSID;
    sun = req.session.storedUsername;
    if (sid == undefined) sid = 'No SessionID';
    if (sun == undefined) sun = 'No Verified Username';
    res.render('test_menu', {sid: sid, sun: sun});
});

router.get('/admin', function (req, res) {
    res.render('admin', {});
});

router.get('/chat', function (req, res) {
    var server = app.server;

    var io = socketio.listen(server);
    console.log('[Socket.io] Ready to accept requests');

    io.sockets.on('connection', function (socket) {
        console.log('connection info : ', socket.request.connection._peername);
        // 소켓 객체이 클라이언트 호스트, 포트 정보 속성으로 추가
        socket.remoteAddress = socket.request.connection._peername.address;
        socket.remotePort = socket.request.connection._peername.port;

        socket.on('message', function (message) {
            console.log('[Socket.io] message 이벤트를 받았습니다');
            console.dir(message);
            socket.emit('Server_message', message);
            /*if (message.recepient == 'ALL') {
                console.dir('나를 포함한 모든 클라이언트에게 message 이벤트를 전송합니다.');
                io.sockets.emit('message', message);
            }*/
        });
    });
    res.render('real_chat', {});
})

/** DB 연결 */
function connectToDB(db) {
    db.connect({}, function (err) {
        if (!err)
            console.log('DB 연결이 성공적으로 연결되었습니다.');
        else
            console.log('DB 연결 실패: ' + err);
    });
}

/** DB 연결 종료 */
function disconnectToDB(db) {
    db.end({}, function (err) {
        if (!err) {
            console.log('DB 연결이 성공적으로 종료되었습니다.');
            // console.log('유저네임: ' + usernameResult.data);
        }
        else
            console.log('DB 연결종료 실패: ' + err);
    });
}


module.exports = router;
